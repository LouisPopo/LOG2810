from menu import *

def main():
    menu()
main()